export default {
  title: "资源概览",
  total: "总计",
  used: "已使用",
  available: "可用",
  cpuCores: "CPU核心",
  memoryGB: "内存(GB)",
  diskGB: "磁盘(GB)",
  bandwidth: "带宽",
  instances: "实例数",
  quota: "配额",
  usage: "使用量"
}
