export default {
  title: '页面未找到',
  message: '抱歉，您访问的页面不存在',
  goHome: '返回首页',
  goBack: '返回上一页'
}
