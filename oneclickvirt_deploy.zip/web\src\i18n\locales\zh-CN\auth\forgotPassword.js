export default {
  title: '忘记密码',
  subtitle: '请输入您的邮箱地址，我们将发送重置密码链接',
  email: '邮箱地址',
  pleaseEnterEmail: '请输入邮箱地址',
  sendResetLink: '发送重置链接',
  backToLogin: '返回登录',
  emailSent: '重置链接已发送到您的邮箱',
  checkEmail: '请检查您的邮箱'
}
