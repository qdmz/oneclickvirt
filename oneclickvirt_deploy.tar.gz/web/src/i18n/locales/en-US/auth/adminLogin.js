export default {
  title: 'Admin Login',
  subtitle: 'Please enter admin account and password'
}
