export default {
  switchTo: '切换到',
  adminView: '管理员视图',
  userView: '用户视图',
  onlyAdminCanSwitch: '只有管理员可以切换视图模式',
  switchedTo: '已切换到',
  noPermission: '您没有权限访问该页面',
  confirmLogout: '确定注销并退出系统吗？',
  tip: '提示',
  switchLanguage: '切换语言',
  languageSwitched: '语言已切换'
}
