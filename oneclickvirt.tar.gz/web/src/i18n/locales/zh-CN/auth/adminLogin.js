export default {
  title: '管理员登录',
  subtitle: '请输入管理员账号和密码'
}
