export default {
  title: '重置密码',
  subtitle: '请输入新密码',
  newPassword: '新密码',
  confirmNewPassword: '确认新密码',
  pleaseEnterNewPassword: '请输入新密码',
  pleaseConfirmNewPassword: '请再次输入新密码',
  resetButton: '重置密码',
  resetSuccess: '密码重置成功',
  resetFailed: '密码重置失败'
}
