export default {
  title: 'Page Not Found',
  message: 'Sorry, the page you are looking for does not exist',
  goHome: 'Go Home',
  goBack: 'Go Back'
}
