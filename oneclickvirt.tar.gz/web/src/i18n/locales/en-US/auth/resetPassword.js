export default {
  title: 'Reset Password',
  subtitle: 'Please enter new password',
  newPassword: 'New Password',
  confirmNewPassword: 'Confirm New Password',
  pleaseEnterNewPassword: 'Please enter new password',
  pleaseConfirmNewPassword: 'Please enter new password again',
  resetButton: 'Reset Password',
  resetSuccess: 'Password reset successful',
  resetFailed: 'Password reset failed'
}
