export default {
  title: "Resource Overview",
  total: "Total",
  used: "Used",
  available: "Available",
  cpuCores: "CPU Cores",
  memoryGB: "Memory (GB)",
  diskGB: "Disk (GB)",
  bandwidth: "Bandwidth",
  instances: "Instances",
  quota: "Quota",
  usage: "Usage"
}
