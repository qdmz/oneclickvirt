export default {
  switchTo: 'Switch to',
  adminView: 'Admin View',
  userView: 'User View',
  onlyAdminCanSwitch: 'Only administrators can switch view modes',
  switchedTo: 'Switched to',
  noPermission: 'You do not have permission to access this page',
  confirmLogout: 'Are you sure you want to logout?',
  tip: 'Tip',
  switchLanguage: 'Switch Language',
  languageSwitched: 'Language switched'
}
